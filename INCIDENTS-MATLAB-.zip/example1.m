% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 1                                                              %
%                                                                           %
%                                                                           %
% This is Example 3.7 in Hernandez et al (2022): A simple network           %
%                                                                           %
% RESULT: The network's finest incidence independent decomposition has 2    %
%    subnetworks.                                                           %
%                                                                           %
% Reference: Hernandez B, Amistas D, De la Cruz R, Fontanil L, de los Reyes %
%    V A, Mendoza E (2022) Independent, incidence independent and weakly    %
%    reversible decompositions of chemical reaction networks. MATCH Commun  %
%    Math Comput Chem, 87(2):367--396.                                      %
%    https://doi.org/10.46793/match.87-2.367H                               %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 1';
model = addReaction(model, 'A->B', ...          % just a visual guide on how the reaction looks like
                           {'A'}, {1}, [1], ... % reactant species, stoichiometry, kinetic order
                           {'B'}, {1}, [ ], ... % product species, stoichiometry, "kinetic order" (if reversible)
                           false);              % reversible or not
model = addReaction(model, 'B->C', ...
                           {'B'}, {1}, [1], ...
                           {'C'}, {1}, [ ], ...
                           false);

% Generate the incidence independent decomposition
[model, I_a, G, P] = incidenceIndepDecomp(model);